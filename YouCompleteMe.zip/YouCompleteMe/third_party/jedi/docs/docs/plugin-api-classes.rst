.. include:: ../global.rst

.. _plugin-api-classes:

API Return Classes
------------------

.. automodule:: api_classes
    :members:
    :undoc-members:
