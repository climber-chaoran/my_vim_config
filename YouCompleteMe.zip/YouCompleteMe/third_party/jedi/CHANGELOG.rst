.. :changelog:

Changelog
---------

0.7.0 (2013-08-09)
++++++++++++++++++
* switched from LGPL to MIT license
* added an Interpreter class to the API to make autocompletion in REPL possible.
* added autocompletion support for namespace packages
* add sith.py, a new random testing method

0.6.0 (2013-05-14)
++++++++++++++++++

* much faster parser with builtin part caching
* a test suite, thanks @tkf

0.5 versions (2012)
+++++++++++++++++++

* Initial development
