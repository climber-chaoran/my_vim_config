﻿using System.Collections.Generic;

namespace OmniSharp.GetCodeActions
{
    public class GetCodeActionsResponse
    {
        public IEnumerable<string> CodeActions { get; set; } 
    }
}