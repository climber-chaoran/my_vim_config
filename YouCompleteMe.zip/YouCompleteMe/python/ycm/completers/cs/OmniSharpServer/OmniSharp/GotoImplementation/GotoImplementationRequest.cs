﻿using OmniSharp.Common;

namespace OmniSharp.GotoImplementation
{
    public class GotoImplementationRequest : Request
    {
    }
}